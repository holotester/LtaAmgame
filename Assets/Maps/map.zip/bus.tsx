<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="bus" tilewidth="32" tileheight="32" tilecount="713" columns="31">
 <image source="bus.png" width="1000" height="737"/>
</tileset>
