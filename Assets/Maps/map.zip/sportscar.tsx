<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="sportscar" tilewidth="32" tileheight="32" tilecount="8649" columns="93">
 <image source="sportscar.png" width="3000" height="3000"/>
</tileset>
