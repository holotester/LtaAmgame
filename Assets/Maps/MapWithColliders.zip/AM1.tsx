<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="AM1" tilewidth="32" tileheight="32" tilecount="3723" columns="51">
 <image source="../AM1.png" width="1654" height="2339"/>
</tileset>
