<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="Thespazztikone_tilemaps" tilewidth="32" tileheight="32" spacing="1" margin="1" tilecount="54" columns="9">
 <image source="Thespazztikone_tilemaps.png" width="320" height="200"/>
</tileset>
