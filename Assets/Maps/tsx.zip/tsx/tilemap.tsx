<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="tilemap" tilewidth="32" tileheight="32" tilecount="126" columns="14">
 <image source="kenney_rpgUrbanKit/Tilemap/tilemap.png" width="458" height="305"/>
</tileset>
