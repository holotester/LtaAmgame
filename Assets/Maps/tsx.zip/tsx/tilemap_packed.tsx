<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="tilemap_packed" tilewidth="16" tileheight="16" tilecount="486" columns="27">
 <image source="kenney_rpgUrbanKit/Tilemap/tilemap_packed.png" width="432" height="288"/>
</tileset>
