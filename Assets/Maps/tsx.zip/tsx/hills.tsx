<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="hills" tilewidth="32" tileheight="32" tilecount="1550" columns="31">
 <image source="hills.png" width="1000" height="1600"/>
</tileset>
