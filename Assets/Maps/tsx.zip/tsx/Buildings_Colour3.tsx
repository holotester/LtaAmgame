<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="Buildings_Colour3" tilewidth="32" tileheight="32" tilecount="5766" columns="93">
 <image source="Buildings_Colour3.png" width="3000" height="2000"/>
</tileset>
