<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="StreetNorthLower" tilewidth="32" tileheight="32" tilecount="72" columns="8">
 <image source="StreetNorthLower.png" width="256" height="288"/>
</tileset>
