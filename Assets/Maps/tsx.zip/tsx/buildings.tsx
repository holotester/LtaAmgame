<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="buildings" tilewidth="32" tileheight="32" tilecount="756" columns="27">
 <image source="buildings.png" width="868" height="920"/>
</tileset>
