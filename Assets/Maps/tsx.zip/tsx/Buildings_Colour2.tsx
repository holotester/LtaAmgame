<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="Buildings_Colour2" tilewidth="32" tileheight="32" tilecount="5766" columns="64">
 <image source="Buildings_Colour2.png" width="2048" height="2048"/>
</tileset>
