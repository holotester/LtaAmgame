<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="stroke4" tilewidth="32" tileheight="32" tilecount="4096" columns="64">
 <image source="2dcityassetpackwithoutline/withoutline/cityfirstprops/stroke4.png" width="2048" height="2048"/>
</tileset>
