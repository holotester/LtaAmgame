<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="terrain_atlas" tilewidth="32" tileheight="32" tilecount="1024" columns="32">
 <editorsettings>
  <export target="terrain_atlas.tsx" format="tsx"/>
 </editorsettings>
 <image source="terrain_atlas.png" width="1024" height="1024"/>
 <wangsets>
  <wangset name="CyclistPath" type="corner" tile="399">
   <wangcolor name="" color="#0000ff" tile="-1" probability="1"/>
   <wangcolor name="" color="#ff7700" tile="-1" probability="1"/>
   <wangcolor name="" color="#00e9ff" tile="-1" probability="1"/>
   <wangtile tileid="398" wangid="0,1,0,2,0,1,0,1"/>
  </wangset>
 </wangsets>
</tileset>
