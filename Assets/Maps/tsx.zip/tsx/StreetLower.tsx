<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="StreetLower" tilewidth="32" tileheight="32" tilecount="200" columns="20">
 <image source="StreetLower.png" width="640" height="320"/>
 <tile id="88">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
</tileset>
