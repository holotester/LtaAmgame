<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="Sample" tilewidth="16" tileheight="16" tilecount="1824" columns="57">
 <image source="kenney_rpgUrbanKit/Sample.png" width="918" height="515"/>
</tileset>
